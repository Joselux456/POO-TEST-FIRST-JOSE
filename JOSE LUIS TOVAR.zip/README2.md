# POO-TEST-FIRST-JOSE
## I: Memoria
* Diagrama
* ![Diagrama 1-MemoriaP](https://user-images.githubusercontent.com/78450716/110181397-b603a700-7dd9-11eb-8a7b-e68e3c5be1f7.png
## IV: Conceptos
*Encapsulamiento: Es cuando todas las variables de una clase solo pueden ser accedidas por los métodos de la clase y no directamente.
Son utiles a la hora de restringir acceso no deseado a las variables.
*Ocultamiento de informacion es la práctica de ocultar secciones de código que no deben ser cambiados al restringir accesos al mismo. Se aplica para evitar daños si el código es modificado por error. en java se implementa al hacer varias variables privadas, y que solo se puedan acceder mediante ciertos "getters".
